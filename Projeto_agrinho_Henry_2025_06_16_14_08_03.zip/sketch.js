function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let umidadeSolo; // Nível de umidade do solo
let temperatura; // Temperatura ambiente
let luminosidade; // Nível de luminosidade
let irrigacaoAtiva = false; // Se a irrigação está ligada ou não
let saudePlanta = 100; // Índice de saúde da planta (100 é saudável)
let irrigacaoManual = false; // Irrigação controlada manualmente
let tempo = 0; // Para o ciclo de tempo

function setup() {
  createCanvas(400, 400);
  umidadeSolo = random(30, 80);  // Umidade inicial
  temperatura = random(18, 35);  // Temperatura inicial
  luminosidade = random(50, 100);  // Luminosidade inicial
  noStroke();
}

function draw() {
  background(220);
  tempo++;

  // Atualizando os parâmetros automaticamente
  if (!irrigacaoManual) {
    umidadeSolo += random(-1, 1);  // Mudança aleatória na umidade
    temperatura += random(-0.1, 0.1);  // Mudança suave na temperatura
    luminosidade += random(-0.5, 0.5);  // Mudança suave na luminosidade

    // Garantir que os valores estejam dentro dos limites
    umidadeSolo = constrain(umidadeSolo, 0, 100);
    temperatura = constrain(temperatura, 15, 40);
    luminosidade = constrain(luminosidade, 0, 100);
  }

  // Mostrar dados de sensores
  textSize(14);
  fill(0);
  text("Umidade do Solo: " + int(umidadeSolo) + "%", 10, 30);
  text("Temperatura: " + int(temperatura) + "°C", 10, 50);
  text("Luminosidade: " + int(luminosidade) + "%", 10, 70);

  // Calculando se a irrigação deve ser automática ou não
  if (umidadeSolo < 30 || temperatura > 30 || luminosidade > 80) {
    irrigacaoAtiva = true;
  } else {
    irrigacaoAtiva = false;
  }

  // Se a irrigação manual estiver ativada, ela sobrepõe a automática
  if (irrigacaoManual) {
    irrigacaoAtiva = true;
  }

  // Atualizar o estado de saúde da planta
  if (irrigacaoAtiva) {
    saudePlanta = min(saudePlanta + 1, 100);  // Melhorar saúde se irrigado
  } else {
    saudePlanta = max(saudePlanta - 0.5, 0);  // Piorar saúde se não irrigado
  }

  // Desenhando a planta (cor muda com a saúde)
  let corPlanta = color(0, 255, 0);
  if (saudePlanta < 50) {
    corPlanta = color(255, 255, 0);  // Planta amarela (falta de água)
  }
  if (saudePlanta < 20) {
    corPlanta = color(139, 69, 19);  // Planta marrom (desidratação)
  }

  fill(corPlanta);
  ellipse(200, 300, 100, 100);  // Representação da planta

  // Desenhando a válvula de irrigação (vermelha se ativada, verde se não)
  if (irrigacaoAtiva) {
    fill(255, 0, 0);
    ellipse(350, 100, 50, 50);  // Válvula aberta
    fill(255);
    text("Irrigação Ativa", 265, 170);
  } else {
    fill(0, 255, 0);
    ellipse(350, 100, 50, 50);  // Válvula fechada
    fill(255);
    text("Irrigação Desligada", 265, 170);
  }

  // Instruções para o usuário
  fill(0);
  textSize(16);
  text("Pressione 'I' para ativar/desativar irrigação manual", 10, 370);
  text("Pressione 'R' para resetar a simulação", 10, 390);
}

// Função para controle manual de irrigação
function keyPressed() {
  if (key === 'I' || key === 'i') {
    irrigacaoManual = !irrigacaoManual;  // Alterna entre manual e automático
  }
  if (key === 'R' || key === 'r') {
    // Resetando os valores para começar a simulação novamente
    umidadeSolo = random(30, 80);
    temperatura = random(18, 35);
    luminosidade = random(50, 100);
    saudePlanta = 100;
    irrigacaoManual = false;
    irrigacaoAtiva = false;
  }


}
